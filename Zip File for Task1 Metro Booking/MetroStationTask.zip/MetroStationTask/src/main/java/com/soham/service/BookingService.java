package com.soham.service;

import com.soham.service.entity.Booking;

public interface BookingService {

	Booking createTicket(String startStation, String endStation, int price);


	Booking useTicket(Long id);

}
