package com.soham.config;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.soham.model.Station;
import com.soham.model.StationData;

import jakarta.annotation.PostConstruct;

@Component
public class StationDataLoader {
    private Map<String, Station> stations;

    @PostConstruct
    public void loadStationData() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        stations = objectMapper.readValue(new File("src/main/resources/stations.json"), StationData.class).getStations();
    }

    public Map<String, Station> getStations() {
        return stations;
    }
}
