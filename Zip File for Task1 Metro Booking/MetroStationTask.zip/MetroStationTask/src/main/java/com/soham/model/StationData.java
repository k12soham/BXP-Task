package com.soham.model;

import java.util.Map;

public class StationData {
 private Map<String, Station> stations;

 public Map<String, Station> getStations() {
     return stations;
 }

 public void setStations(Map<String, Station> stations) {
     this.stations = stations;
 }
}
