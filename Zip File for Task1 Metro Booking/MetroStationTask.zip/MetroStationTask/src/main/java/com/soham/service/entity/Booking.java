package com.soham.service.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class Booking {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    private String startStation;
	    private String endStation;
	    private int price;
	    private LocalDateTime createdTime;
	    private LocalDateTime expiryTime;
	    private int usageCount;
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getStartStation() {
			return startStation;
		}
		public void setStartStation(String startStation) {
			this.startStation = startStation;
		}
		public String getEndStation() {
			return endStation;
		}
		public void setEndStation(String endStation) {
			this.endStation = endStation;
		}
		public int getPrice() {
			return price;
		}
		public void setPrice(int price) {
			this.price = price;
		}
		public LocalDateTime getCreatedTime() {
			return createdTime;
		}
		public void setCreatedTime(LocalDateTime createdTime) {
			this.createdTime = createdTime;
		}
		public LocalDateTime getExpiryTime() {
			return expiryTime;
		}
		public void setExpiryTime(LocalDateTime expiryTime) {
			this.expiryTime = expiryTime;
		}
		public int getUsageCount() {
			return usageCount;
		}
		public void setUsageCount(int usageCount) {
			this.usageCount = usageCount;
		}
	    
	    
	    
}
