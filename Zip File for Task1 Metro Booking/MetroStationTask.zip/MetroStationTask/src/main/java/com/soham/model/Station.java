package com.soham.model;

public class Station {
 private boolean startStation;
 private boolean lastStation;
 private int price;

 public boolean isStartStation() {
     return startStation;
 }

 public void setStartStation(boolean startStation) {
     this.startStation = startStation;
 }

 public boolean isLastStation() {
     return lastStation;
 }

 public void setLastStation(boolean lastStation) {
     this.lastStation = lastStation;
 }

 public int getPrice() {
     return price;
 }

 public void setPrice(int price) {
     this.price = price;
 }
}

