package com.soham.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.soham.config.StationDataLoader;
import com.soham.model.Station;
import com.soham.service.BookingService;
import com.soham.service.entity.Booking;

@RestController
@RequestMapping("/booking")
public class BookingController {

	@Autowired
	private BookingService bookingService;
	@Autowired
	private StationDataLoader stationDataLoader;

	@GetMapping("/stations")
	public Map<String, Station> getStations() {
		return stationDataLoader.getStations();
	}

	@PostMapping("/book")
	public Booking bookTicket(@RequestParam String startStation, @RequestParam String endStation) {
		Map<String, Station> stations = stationDataLoader.getStations();
		int price = Math.abs(stations.get(startStation).getPrice() - stations.get(endStation).getPrice());
		return bookingService.createTicket(startStation, endStation, price);
	}

	@PostMapping("/use/{id}")
	public Booking useTicket(@PathVariable Long id) {
		return bookingService.useTicket(id);
	}

}
