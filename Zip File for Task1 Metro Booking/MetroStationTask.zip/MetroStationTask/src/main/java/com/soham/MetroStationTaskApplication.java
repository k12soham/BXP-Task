package com.soham;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MetroStationTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(MetroStationTaskApplication.class, args);
	}

}
