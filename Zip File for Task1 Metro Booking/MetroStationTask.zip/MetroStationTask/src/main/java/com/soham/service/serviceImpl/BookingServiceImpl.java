package com.soham.service.serviceImpl;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.soham.repository.BookingRepository;
import com.soham.service.BookingService;
import com.soham.service.entity.Booking;

@Service
public class BookingServiceImpl implements BookingService {
	@Autowired
	private BookingRepository bookingRepository;

	@Override
	public Booking createTicket(String startStation, String endStation, int price) {
		try {
			Booking ticket = new Booking();
			ticket.setStartStation(startStation);
			ticket.setEndStation(endStation);
			ticket.setPrice(price);
			ticket.setCreatedTime(LocalDateTime.now());
			ticket.setExpiryTime(LocalDateTime.now().plusHours(18));
			ticket.setUsageCount(0);
			return bookingRepository.save(ticket);
		} catch (Exception e) {

			e.printStackTrace();
			throw new RuntimeException("Ticket not created, Try Again", e);
		}
	}

	@Override
	public Booking useTicket(Long id) {
		try {
			Booking ticket = getTicket(id);
			if (ticket != null && ticket.getUsageCount() < 2 && LocalDateTime.now().isBefore(ticket.getExpiryTime())) {
				ticket.setUsageCount(ticket.getUsageCount() + 1);
				return bookingRepository.save(ticket);
			} else {
				throw new RuntimeException("Ticket cannot be used");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Ticket cannot be used", e);
		}
	}

	public Booking getTicket(Long id) {
		try {
			Optional<Booking> optionalTicket = bookingRepository.findById(id);
			if (optionalTicket.isPresent()) {
				return optionalTicket.get();
			} else {

				throw new RuntimeException("Ticket not found");
			}
		} catch (Exception e) {

			e.printStackTrace();
			throw new RuntimeException("Ticket not found", e);
		}
	}

}
